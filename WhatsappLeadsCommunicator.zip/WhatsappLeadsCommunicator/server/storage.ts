import { users, contacts, messageTemplates, campaigns, campaignContacts, type User, type InsertUser, type Contact, type InsertContact, type MessageTemplate, type InsertMessageTemplate, type Campaign, type InsertCampaign, type CampaignContact, type InsertCampaignContact } from "@shared/schema";
import { db } from './db';
import { eq, and, count } from 'drizzle-orm';

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact methods
  getContacts(userId: number): Promise<Contact[]>;
  getContact(id: number, userId: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  createContacts(contacts: InsertContact[]): Promise<Contact[]>;
  updateContact(id: number, userId: number, updates: Partial<Contact>): Promise<Contact | undefined>;
  deleteContact(id: number, userId: number): Promise<boolean>;
  
  // Message template methods
  getMessageTemplates(userId: number): Promise<MessageTemplate[]>;
  getMessageTemplate(id: number, userId: number): Promise<MessageTemplate | undefined>;
  createMessageTemplate(template: InsertMessageTemplate): Promise<MessageTemplate>;
  updateMessageTemplate(id: number, userId: number, updates: Partial<MessageTemplate>): Promise<MessageTemplate | undefined>;
  deleteMessageTemplate(id: number, userId: number): Promise<boolean>;
  
  // Campaign methods
  getCampaigns(userId: number): Promise<Campaign[]>;
  getCampaign(id: number, userId: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, userId: number, updates: Partial<Campaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: number, userId: number): Promise<boolean>;
  
  // Campaign contact methods
  getCampaignContacts(campaignId: number): Promise<CampaignContact[]>;
  createCampaignContact(campaignContact: InsertCampaignContact): Promise<CampaignContact>;
  updateCampaignContact(id: number, updates: Partial<CampaignContact>): Promise<CampaignContact | undefined>;
  
  // Analytics methods
  getUserStats(userId: number): Promise<{
    totalContacts: number;
    messagesSent: number;
    deliveryRate: number;
    activeCampaigns: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private contacts: Map<number, Contact> = new Map();
  private messageTemplates: Map<number, MessageTemplate> = new Map();
  private campaigns: Map<number, Campaign> = new Map();
  private campaignContacts: Map<number, CampaignContact> = new Map();
  private currentUserId = 1;
  private currentContactId = 1;
  private currentTemplateId = 1;
  private currentCampaignId = 1;
  private currentCampaignContactId = 1;

  constructor() {
    // Criar usuário de demonstração de forma assíncrona
    this.createDemoUser().catch(console.error);
  }

  private async createDemoUser() {
    // Hash da senha "demo123"
    const bcrypt = await import('bcrypt');
    const hashedPassword = await bcrypt.default.hash('demo123', 10);
    
    const demoUser: User = {
      id: 1,
      email: 'demo@whatsapp-sender.com',
      fullName: 'Usuário Demo',
      password: hashedPassword,
      createdAt: new Date(),
    };
    this.users.set(1, demoUser);
    this.currentUserId = 2;

    // Criar alguns contatos de exemplo
    const demoContacts: Contact[] = [
      {
        id: 1,
        userId: 1,
        name: 'João Silva',
        phone: '+5511999887766',
        email: 'joao@empresa.com',
        company: 'Empresa ABC',
        status: 'active',
        lastMessageSent: new Date(Date.now() - 86400000), // 1 dia atrás
        createdAt: new Date(Date.now() - 86400000 * 7), // 7 dias atrás
      },
      {
        id: 2,
        userId: 1,
        name: 'Maria Santos',
        phone: '+5511888776655',
        email: 'maria@loja.com',
        company: 'Loja XYZ',
        status: 'active',
        lastMessageSent: new Date(Date.now() - 43200000), // 12 horas atrás
        createdAt: new Date(Date.now() - 86400000 * 3), // 3 dias atrás
      },
      {
        id: 3,
        userId: 1,
        name: 'Carlos Oliveira',
        phone: '+5511777665544',
        email: null,
        company: null,
        status: 'pending',
        lastMessageSent: null,
        createdAt: new Date(Date.now() - 86400000 * 2), // 2 dias atrás
      },
    ];

    demoContacts.forEach(contact => {
      this.contacts.set(contact.id, contact);
    });
    this.currentContactId = 4;

    // Criar templates de exemplo
    const demoTemplates: MessageTemplate[] = [
      {
        id: 1,
        userId: 1,
        name: 'Boas-vindas',
        content: 'Olá {nome}! 👋 Bem-vindo(a) à nossa empresa. Estamos muito felizes em tê-lo(a) conosco!',
        category: 'saudacao',
        priority: 'high',
        usageCount: 15,
        createdAt: new Date(Date.now() - 86400000 * 10),
      },
      {
        id: 2,
        userId: 1,
        name: 'Promoção Especial',
        content: 'Oi {nome}! 🎉 Temos uma oferta especial só para você: 20% de desconto em todos os produtos. Use o código PROMO20 até o final do mês!',
        category: 'promocao',
        priority: 'normal',
        usageCount: 8,
        createdAt: new Date(Date.now() - 86400000 * 5),
      },
      {
        id: 3,
        userId: 1,
        name: 'Lembrete de Reunião',
        content: 'Olá {nome}, lembro que temos nossa reunião marcada para amanhã às 14h. Confirma sua presença? 📅',
        category: 'lembrete',
        priority: 'high',
        usageCount: 3,
        createdAt: new Date(Date.now() - 86400000 * 2),
      },
    ];

    demoTemplates.forEach(template => {
      this.messageTemplates.set(template.id, template);
    });
    this.currentTemplateId = 4;

    // Criar campanha de exemplo
    const demoCampaign: Campaign = {
      id: 1,
      userId: 1,
      name: 'Campanha de Boas-vindas Q4',
      templateId: 1,
      status: 'completed',
      scheduledAt: new Date(Date.now() - 86400000 * 3),
      completedAt: new Date(Date.now() - 86400000 * 2),
      totalContacts: 50,
      messagesSent: 48,
      messagesDelivered: 45,
      messagesRead: 38,
      messagesReplied: 12,
      sendingSpeed: 'normal',
      createdAt: new Date(Date.now() - 86400000 * 5),
    };

    this.campaigns.set(1, demoCampaign);
    this.currentCampaignId = 2;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getContacts(userId: number): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter(contact => contact.userId === userId);
  }

  async getContact(id: number, userId: number): Promise<Contact | undefined> {
    const contact = this.contacts.get(id);
    return contact?.userId === userId ? contact : undefined;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const contact: Contact = {
      ...insertContact,
      id,
      lastMessageSent: null,
      createdAt: new Date(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async createContacts(insertContacts: InsertContact[]): Promise<Contact[]> {
    const contacts: Contact[] = [];
    for (const insertContact of insertContacts) {
      const contact = await this.createContact(insertContact);
      contacts.push(contact);
    }
    return contacts;
  }

  async updateContact(id: number, userId: number, updates: Partial<Contact>): Promise<Contact | undefined> {
    const contact = await this.getContact(id, userId);
    if (!contact) return undefined;
    
    const updatedContact = { ...contact, ...updates };
    this.contacts.set(id, updatedContact);
    return updatedContact;
  }

  async deleteContact(id: number, userId: number): Promise<boolean> {
    const contact = await this.getContact(id, userId);
    if (!contact) return false;
    
    return this.contacts.delete(id);
  }

  async getMessageTemplates(userId: number): Promise<MessageTemplate[]> {
    return Array.from(this.messageTemplates.values()).filter(template => template.userId === userId);
  }

  async getMessageTemplate(id: number, userId: number): Promise<MessageTemplate | undefined> {
    const template = this.messageTemplates.get(id);
    return template?.userId === userId ? template : undefined;
  }

  async createMessageTemplate(insertTemplate: InsertMessageTemplate): Promise<MessageTemplate> {
    const id = this.currentTemplateId++;
    const template: MessageTemplate = {
      ...insertTemplate,
      id,
      usageCount: 0,
      createdAt: new Date(),
    };
    this.messageTemplates.set(id, template);
    return template;
  }

  async updateMessageTemplate(id: number, userId: number, updates: Partial<MessageTemplate>): Promise<MessageTemplate | undefined> {
    const template = await this.getMessageTemplate(id, userId);
    if (!template) return undefined;
    
    const updatedTemplate = { ...template, ...updates };
    this.messageTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteMessageTemplate(id: number, userId: number): Promise<boolean> {
    const template = await this.getMessageTemplate(id, userId);
    if (!template) return false;
    
    return this.messageTemplates.delete(id);
  }

  async getCampaigns(userId: number): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).filter(campaign => campaign.userId === userId);
  }

  async getCampaign(id: number, userId: number): Promise<Campaign | undefined> {
    const campaign = this.campaigns.get(id);
    return campaign?.userId === userId ? campaign : undefined;
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.currentCampaignId++;
    const campaign: Campaign = {
      ...insertCampaign,
      id,
      completedAt: null,
      messagesSent: 0,
      messagesDelivered: 0,
      messagesRead: 0,
      messagesReplied: 0,
      createdAt: new Date(),
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: number, userId: number, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const campaign = await this.getCampaign(id, userId);
    if (!campaign) return undefined;
    
    const updatedCampaign = { ...campaign, ...updates };
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: number, userId: number): Promise<boolean> {
    const campaign = await this.getCampaign(id, userId);
    if (!campaign) return false;
    
    return this.campaigns.delete(id);
  }

  async getCampaignContacts(campaignId: number): Promise<CampaignContact[]> {
    return Array.from(this.campaignContacts.values()).filter(cc => cc.campaignId === campaignId);
  }

  async createCampaignContact(insertCampaignContact: InsertCampaignContact): Promise<CampaignContact> {
    const id = this.currentCampaignContactId++;
    const campaignContact: CampaignContact = {
      ...insertCampaignContact,
      id,
      sentAt: null,
      deliveredAt: null,
      readAt: null,
      repliedAt: null,
      errorMessage: null,
    };
    this.campaignContacts.set(id, campaignContact);
    return campaignContact;
  }

  async updateCampaignContact(id: number, updates: Partial<CampaignContact>): Promise<CampaignContact | undefined> {
    const campaignContact = this.campaignContacts.get(id);
    if (!campaignContact) return undefined;
    
    const updatedCampaignContact = { ...campaignContact, ...updates };
    this.campaignContacts.set(id, updatedCampaignContact);
    return updatedCampaignContact;
  }

  async getUserStats(userId: number): Promise<{
    totalContacts: number;
    messagesSent: number;
    deliveryRate: number;
    activeCampaigns: number;
  }> {
    const contacts = await this.getContacts(userId);
    const campaigns = await this.getCampaigns(userId);
    
    const totalMessagesSent = campaigns.reduce((sum, c) => sum + c.messagesSent, 0);
    const totalMessagesDelivered = campaigns.reduce((sum, c) => sum + c.messagesDelivered, 0);
    const deliveryRate = totalMessagesSent > 0 ? (totalMessagesDelivered / totalMessagesSent) * 100 : 0;
    const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

    return {
      totalContacts: contacts.length,
      messagesSent: totalMessagesSent,
      deliveryRate: Math.round(deliveryRate * 10) / 10,
      activeCampaigns,
    };
  }
}

// Implementação PostgreSQL usando Drizzle
export class PostgreSQLStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Contact methods
  async getContacts(userId: number): Promise<Contact[]> {
    return await db.select().from(contacts).where(eq(contacts.userId, userId));
  }

  async getContact(id: number, userId: number): Promise<Contact | undefined> {
    const result = await db.select().from(contacts)
      .where(and(eq(contacts.id, id), eq(contacts.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const result = await db.insert(contacts).values(insertContact).returning();
    return result[0];
  }

  async createContacts(insertContacts: InsertContact[]): Promise<Contact[]> {
    const result = await db.insert(contacts).values(insertContacts).returning();
    return result;
  }

  async updateContact(id: number, userId: number, updates: Partial<Contact>): Promise<Contact | undefined> {
    const result = await db.update(contacts)
      .set(updates)
      .where(and(eq(contacts.id, id), eq(contacts.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteContact(id: number, userId: number): Promise<boolean> {
    const result = await db.delete(contacts)
      .where(and(eq(contacts.id, id), eq(contacts.userId, userId)));
    return result.rowCount > 0;
  }

  // Message template methods
  async getMessageTemplates(userId: number): Promise<MessageTemplate[]> {
    return await db.select().from(messageTemplates).where(eq(messageTemplates.userId, userId));
  }

  async getMessageTemplate(id: number, userId: number): Promise<MessageTemplate | undefined> {
    const result = await db.select().from(messageTemplates)
      .where(and(eq(messageTemplates.id, id), eq(messageTemplates.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createMessageTemplate(insertTemplate: InsertMessageTemplate): Promise<MessageTemplate> {
    const result = await db.insert(messageTemplates).values(insertTemplate).returning();
    return result[0];
  }

  async updateMessageTemplate(id: number, userId: number, updates: Partial<MessageTemplate>): Promise<MessageTemplate | undefined> {
    const result = await db.update(messageTemplates)
      .set(updates)
      .where(and(eq(messageTemplates.id, id), eq(messageTemplates.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteMessageTemplate(id: number, userId: number): Promise<boolean> {
    const result = await db.delete(messageTemplates)
      .where(and(eq(messageTemplates.id, id), eq(messageTemplates.userId, userId)));
    return result.rowCount > 0;
  }

  // Campaign methods
  async getCampaigns(userId: number): Promise<Campaign[]> {
    return await db.select().from(campaigns).where(eq(campaigns.userId, userId));
  }

  async getCampaign(id: number, userId: number): Promise<Campaign | undefined> {
    const result = await db.select().from(campaigns)
      .where(and(eq(campaigns.id, id), eq(campaigns.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const result = await db.insert(campaigns).values(insertCampaign).returning();
    return result[0];
  }

  async updateCampaign(id: number, userId: number, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const result = await db.update(campaigns)
      .set(updates)
      .where(and(eq(campaigns.id, id), eq(campaigns.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteCampaign(id: number, userId: number): Promise<boolean> {
    const result = await db.delete(campaigns)
      .where(and(eq(campaigns.id, id), eq(campaigns.userId, userId)));
    return result.rowCount > 0;
  }

  // Campaign contact methods
  async getCampaignContacts(campaignId: number): Promise<CampaignContact[]> {
    return await db.select().from(campaignContacts).where(eq(campaignContacts.campaignId, campaignId));
  }

  async createCampaignContact(insertCampaignContact: InsertCampaignContact): Promise<CampaignContact> {
    const result = await db.insert(campaignContacts).values(insertCampaignContact).returning();
    return result[0];
  }

  async updateCampaignContact(id: number, updates: Partial<CampaignContact>): Promise<CampaignContact | undefined> {
    const result = await db.update(campaignContacts)
      .set(updates)
      .where(eq(campaignContacts.id, id))
      .returning();
    return result[0];
  }

  // Analytics methods
  async getUserStats(userId: number): Promise<{
    totalContacts: number;
    messagesSent: number;
    deliveryRate: number;
    activeCampaigns: number;
  }> {
    const [contactCount] = await db.select({ count: count() }).from(contacts).where(eq(contacts.userId, userId));
    const [activeCampaignCount] = await db.select({ count: count() }).from(campaigns)
      .where(and(eq(campaigns.userId, userId), eq(campaigns.status, 'active')));
    
    const userCampaigns = await db.select().from(campaigns).where(eq(campaigns.userId, userId));
    const totalSent = userCampaigns.reduce((sum, campaign) => sum + campaign.messagesSent, 0);
    const totalDelivered = userCampaigns.reduce((sum, campaign) => sum + campaign.messagesDelivered, 0);
    const deliveryRate = totalSent > 0 ? (totalDelivered / totalSent) * 100 : 0;

    return {
      totalContacts: contactCount.count,
      messagesSent: totalSent,
      deliveryRate,
      activeCampaigns: activeCampaignCount.count,
    };
  }
}

// Use memory storage for now - will switch to Supabase after connection is resolved
export const storage = new MemStorage();
