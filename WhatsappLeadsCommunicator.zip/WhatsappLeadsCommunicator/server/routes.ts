import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import csv from "csv-parser";
import { Readable } from "stream";
import { insertUserSchema, insertContactSchema, insertMessageTemplateSchema, insertCampaignSchema } from "@shared/schema";
import { setupDatabase } from "./setup-database";

const JWT_SECRET = process.env.JWT_SECRET || "your-jwt-secret";
const upload = multer({ storage: multer.memoryStorage() });

// Auth middleware
const authMiddleware = async (req: any, res: any, next: any) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
    const user = await storage.getUser(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ message: "Invalid token" });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, fullName } = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        fullName,
      });

      // Generate token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET);
      
      res.json({ user: { id: user.id, email: user.email, fullName: user.fullName }, token });
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET);
      
      res.json({ user: { id: user.id, email: user.email, fullName: user.fullName }, token });
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: any, res) => {
    const { password, ...userWithoutPassword } = req.user;
    res.json({ user: userWithoutPassword });
  });

  // Contact routes
  app.get("/api/contacts", authMiddleware, async (req: any, res) => {
    try {
      const contacts = await storage.getContacts(req.user.id);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching contacts" });
    }
  });

  app.post("/api/contacts", authMiddleware, async (req: any, res) => {
    try {
      const contactData = insertContactSchema.parse({ ...req.body, userId: req.user.id });
      const contact = await storage.createContact(contactData);
      res.json(contact);
    } catch (error) {
      res.status(400).json({ message: "Invalid contact data" });
    }
  });

  app.post("/api/contacts/import", authMiddleware, upload.single("file"), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const contacts: any[] = [];
      const stream = Readable.from(req.file.buffer);

      await new Promise((resolve, reject) => {
        stream
          .pipe(csv())
          .on("data", (row) => {
            // Expected CSV columns: name, phone, email, company
            if (row.name && row.phone) {
              contacts.push({
                userId: req.user.id,
                name: row.name,
                phone: row.phone,
                email: row.email || null,
                company: row.company || null,
                status: "active",
              });
            }
          })
          .on("end", resolve)
          .on("error", reject);
      });

      const createdContacts = await storage.createContacts(contacts);
      res.json({ message: `${createdContacts.length} contacts imported successfully`, contacts: createdContacts });
    } catch (error) {
      res.status(500).json({ message: "Error importing contacts" });
    }
  });

  app.put("/api/contacts/:id", authMiddleware, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const contact = await storage.updateContact(id, req.user.id, updates);
      
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      res.json(contact);
    } catch (error) {
      res.status(400).json({ message: "Error updating contact" });
    }
  });

  app.delete("/api/contacts/:id", authMiddleware, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteContact(id, req.user.id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      res.json({ message: "Contact deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Error deleting contact" });
    }
  });

  // Message template routes
  app.get("/api/templates", authMiddleware, async (req: any, res) => {
    try {
      const templates = await storage.getMessageTemplates(req.user.id);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Error fetching templates" });
    }
  });

  app.post("/api/templates", authMiddleware, async (req: any, res) => {
    try {
      const templateData = insertMessageTemplateSchema.parse({ ...req.body, userId: req.user.id });
      const template = await storage.createMessageTemplate(templateData);
      res.json(template);
    } catch (error) {
      res.status(400).json({ message: "Invalid template data" });
    }
  });

  app.put("/api/templates/:id", authMiddleware, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const template = await storage.updateMessageTemplate(id, req.user.id, updates);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(400).json({ message: "Error updating template" });
    }
  });

  app.delete("/api/templates/:id", authMiddleware, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteMessageTemplate(id, req.user.id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json({ message: "Template deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Error deleting template" });
    }
  });

  // Campaign routes
  app.get("/api/campaigns", authMiddleware, async (req: any, res) => {
    try {
      const campaigns = await storage.getCampaigns(req.user.id);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Error fetching campaigns" });
    }
  });

  app.post("/api/campaigns", authMiddleware, async (req: any, res) => {
    try {
      const campaignData = insertCampaignSchema.parse({ ...req.body, userId: req.user.id });
      const campaign = await storage.createCampaign(campaignData);
      res.json(campaign);
    } catch (error) {
      res.status(400).json({ message: "Invalid campaign data" });
    }
  });

  app.put("/api/campaigns/:id", authMiddleware, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const campaign = await storage.updateCampaign(id, req.user.id, updates);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      res.status(400).json({ message: "Error updating campaign" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/stats", authMiddleware, async (req: any, res) => {
    try {
      const stats = await storage.getUserStats(req.user.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Error fetching stats" });
    }
  });

  const httpServer = createServer(app);
  // Endpoint especial para configurar o banco Supabase
  app.post("/api/setup-database", async (req, res) => {
    try {
      await setupDatabase();
      res.json({ message: "Banco Supabase configurado com sucesso!", success: true });
    } catch (error) {
      console.error("Erro ao configurar banco:", error);
      res.status(500).json({ message: "Erro ao configurar banco", error: error.message });
    }
  });

  return httpServer;
}
