import { db } from './db';
import { sql } from 'drizzle-orm';

export async function setupDatabase() {
  try {
    console.log('🚀 Iniciando configuração do banco Supabase...');

    // Criar tabela de usuários
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" serial PRIMARY KEY NOT NULL,
        "email" text NOT NULL,
        "password" text NOT NULL,
        "full_name" text NOT NULL,
        "created_at" timestamp DEFAULT now() NOT NULL,
        CONSTRAINT "users_email_unique" UNIQUE("email")
      );
    `);
    console.log('✅ Tabela users criada');

    // Criar tabela de contatos
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "contacts" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "name" text NOT NULL,
        "phone" text NOT NULL,
        "email" text,
        "company" text,
        "status" text DEFAULT 'active' NOT NULL,
        "last_message_sent" timestamp,
        "created_at" timestamp DEFAULT now() NOT NULL
      );
    `);
    console.log('✅ Tabela contacts criada');

    // Criar tabela de templates de mensagem
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "message_templates" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "name" text NOT NULL,
        "content" text NOT NULL,
        "category" text NOT NULL,
        "priority" text DEFAULT 'normal' NOT NULL,
        "usage_count" integer DEFAULT 0 NOT NULL,
        "created_at" timestamp DEFAULT now() NOT NULL
      );
    `);
    console.log('✅ Tabela message_templates criada');

    // Criar tabela de campanhas
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "campaigns" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "name" text NOT NULL,
        "template_id" integer NOT NULL,
        "status" text DEFAULT 'pending' NOT NULL,
        "scheduled_at" timestamp,
        "completed_at" timestamp,
        "total_contacts" integer DEFAULT 0 NOT NULL,
        "messages_sent" integer DEFAULT 0 NOT NULL,
        "messages_delivered" integer DEFAULT 0 NOT NULL,
        "messages_read" integer DEFAULT 0 NOT NULL,
        "messages_replied" integer DEFAULT 0 NOT NULL,
        "sending_speed" text DEFAULT 'normal' NOT NULL,
        "created_at" timestamp DEFAULT now() NOT NULL
      );
    `);
    console.log('✅ Tabela campaigns criada');

    // Criar tabela de contatos de campanha
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "campaign_contacts" (
        "id" serial PRIMARY KEY NOT NULL,
        "campaign_id" integer NOT NULL,
        "contact_id" integer NOT NULL,
        "status" text DEFAULT 'pending' NOT NULL,
        "sent_at" timestamp,
        "delivered_at" timestamp,
        "read_at" timestamp,
        "replied_at" timestamp,
        "error_message" text
      );
    `);
    console.log('✅ Tabela campaign_contacts criada');

    // Criar usuário de demonstração
    const bcrypt = await import('bcrypt');
    const hashedPassword = await bcrypt.default.hash('demo123', 10);
    
    await db.execute(sql`
      INSERT INTO users (email, password, full_name)
      VALUES ('demo@whatsapp-sender.com', ${hashedPassword}, 'Usuário Demo')
      ON CONFLICT (email) DO NOTHING;
    `);
    console.log('✅ Usuário demo criado');

    // Buscar o ID do usuário demo
    const demoUser = await db.execute(sql`
      SELECT id FROM users WHERE email = 'demo@whatsapp-sender.com' LIMIT 1;
    `);
    const userId = demoUser.rows[0]?.id;

    if (userId) {
      // Criar contatos de exemplo
      await db.execute(sql`
        INSERT INTO contacts (user_id, name, phone, email, company, status, last_message_sent)
        VALUES 
          (${userId}, 'João Silva', '+5511999887766', 'joao@empresa.com', 'Empresa ABC', 'active', NOW() - INTERVAL '1 day'),
          (${userId}, 'Maria Santos', '+5511888776655', 'maria@loja.com', 'Loja XYZ', 'active', NOW() - INTERVAL '12 hours'),
          (${userId}, 'Carlos Oliveira', '+5511777665544', null, null, 'pending', null)
        ON CONFLICT DO NOTHING;
      `);
      console.log('✅ Contatos de exemplo criados');

      // Criar templates de exemplo
      await db.execute(sql`
        INSERT INTO message_templates (user_id, name, content, category, priority, usage_count)
        VALUES 
          (${userId}, 'Boas-vindas', 'Olá {nome}! 👋 Bem-vindo(a) à nossa empresa. Estamos muito felizes em tê-lo(a) conosco!', 'saudacao', 'high', 15),
          (${userId}, 'Promoção Especial', 'Oi {nome}! 🎉 Temos uma oferta especial só para você: 20% de desconto em todos os produtos. Use o código PROMO20 até o final do mês!', 'promocao', 'normal', 8),
          (${userId}, 'Lembrete de Reunião', 'Olá {nome}, lembro que temos nossa reunião marcada para amanhã às 14h. Confirma sua presença? 📅', 'lembrete', 'high', 3)
        ON CONFLICT DO NOTHING;
      `);
      console.log('✅ Templates de exemplo criados');

      // Buscar o ID do primeiro template
      const template = await db.execute(sql`
        SELECT id FROM message_templates WHERE user_id = ${userId} LIMIT 1;
      `);
      const templateId = template.rows[0]?.id;

      if (templateId) {
        // Criar campanha de exemplo
        await db.execute(sql`
          INSERT INTO campaigns (user_id, name, template_id, status, scheduled_at, completed_at, total_contacts, messages_sent, messages_delivered, messages_read, messages_replied, sending_speed)
          VALUES 
            (${userId}, 'Campanha de Boas-vindas Q4', ${templateId}, 'completed', NOW() - INTERVAL '3 days', NOW() - INTERVAL '2 days', 50, 48, 45, 38, 12, 'normal')
          ON CONFLICT DO NOTHING;
        `);
        console.log('✅ Campanha de exemplo criada');
      }
    }

    console.log('🎉 Banco Supabase configurado com sucesso!');
    return true;
  } catch (error) {
    console.error('❌ Erro ao configurar banco:', error);
    throw error;
  }
}