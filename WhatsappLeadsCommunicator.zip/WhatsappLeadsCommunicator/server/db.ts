import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "../shared/schema";

// Configuração correta para Supabase
const DATABASE_URL =
  "postgresql://postgres:S3t33ms3t3S4c0ch310@db.pathdchuvdlkdxrkewng.supabase.co:5432/postgres";

console.log("Conectando ao Supabase...");

const client = postgres(DATABASE_URL);
export const db = drizzle(client, { schema });
