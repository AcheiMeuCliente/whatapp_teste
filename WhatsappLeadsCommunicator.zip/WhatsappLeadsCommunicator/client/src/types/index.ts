export interface User {
  id: number;
  email: string;
  fullName: string;
}

export interface Contact {
  id: number;
  userId: number;
  name: string;
  phone: string;
  email?: string;
  company?: string;
  status: 'active' | 'blocked' | 'pending';
  lastMessageSent?: Date;
  createdAt: Date;
}

export interface MessageTemplate {
  id: number;
  userId: number;
  name: string;
  content: string;
  category: string;
  priority: 'high' | 'normal' | 'low';
  usageCount: number;
  createdAt: Date;
}

export interface Campaign {
  id: number;
  userId: number;
  name: string;
  templateId: number;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  scheduledAt?: Date;
  completedAt?: Date;
  totalContacts: number;
  messagesSent: number;
  messagesDelivered: number;
  messagesRead: number;
  messagesReplied: number;
  sendingSpeed: 'fast' | 'normal' | 'slow';
  createdAt: Date;
}

export interface UserStats {
  totalContacts: number;
  messagesSent: number;
  deliveryRate: number;
  activeCampaigns: number;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, fullName: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
}
