import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Sidebar } from '@/components/dashboard/sidebar';
import { Header } from '@/components/dashboard/header';
import { DashboardTab } from '@/components/dashboard/dashboard-tab';
import { ContactsTab } from '@/components/dashboard/contacts-tab';
import { MessagesTab } from '@/components/dashboard/messages-tab';
import { CampaignsTab } from '@/components/dashboard/campaigns-tab';
import { AnalyticsTab } from '@/components/dashboard/analytics-tab';
import { ComplianceTab } from '@/components/dashboard/compliance-tab';
import { HelpCenter } from '@/components/dashboard/help-center';

export default function DashboardPage() {
  const { user, logout, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (!user && !loading) {
      setLocation('/login');
    }
  }, [user, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to login
  }

  const handleLogout = () => {
    logout();
    setLocation('/login');
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'contacts':
        return <ContactsTab />;
      case 'messages':
        return <MessagesTab />;
      case 'campaigns':
        return <CampaignsTab />;
      case 'analytics':
        return <AnalyticsTab />;
      case 'compliance':
        return <ComplianceTab />;
      case 'help':
        return <HelpCenter />;
      default:
        return <DashboardTab onTabChange={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onLogout={handleLogout}
        isOpen={sidebarOpen}
      />

      {/* Main Content */}
      <div className="lg:pl-64">
        {/* Header */}
        <Header
          title={activeTab}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />

        {/* Page Content */}
        <main className="p-6">
          {renderTabContent()}
        </main>
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
