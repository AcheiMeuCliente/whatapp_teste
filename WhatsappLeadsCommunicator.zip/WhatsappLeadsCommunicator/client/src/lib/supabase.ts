// This file is kept for potential future Supabase client usage
// Currently using custom auth with JWT tokens
export const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
export const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
