import { apiRequest } from './queryClient';
import type { User } from '@/types';

export interface AuthResponse {
  user: User;
  token: string;
}

export class AuthService {
  private static TOKEN_KEY = 'whatsapp_sender_token';
  private static USER_KEY = 'whatsapp_sender_user';

  static getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  static getUser(): User | null {
    const user = localStorage.getItem(this.USER_KEY);
    return user ? JSON.parse(user) : null;
  }

  static setAuth(user: User, token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }

  static clearAuth(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }

  static async login(email: string, password: string): Promise<AuthResponse> {
    const response = await apiRequest('POST', '/api/auth/login', { email, password });
    const data = await response.json();
    this.setAuth(data.user, data.token);
    return data;
  }

  static async register(email: string, password: string, fullName: string): Promise<AuthResponse> {
    const response = await apiRequest('POST', '/api/auth/register', { email, password, fullName });
    const data = await response.json();
    this.setAuth(data.user, data.token);
    return data;
  }

  static async verifyToken(): Promise<User | null> {
    const token = this.getToken();
    if (!token) return null;

    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        credentials: 'include',
      });

      if (!response.ok) {
        this.clearAuth();
        return null;
      }

      const data = await response.json();
      return data.user;
    } catch (error) {
      this.clearAuth();
      return null;
    }
  }

  static logout(): void {
    this.clearAuth();
  }
}
