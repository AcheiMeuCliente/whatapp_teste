import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Send, CheckCircle, Rocket, Plus, Upload, TrendingUp, ChevronRight } from 'lucide-react';
import { AuthService } from '@/lib/auth';
import type { UserStats } from '@/types';

interface DashboardTabProps {
  onTabChange: (tab: string) => void;
}

export function DashboardTab({ onTabChange }: DashboardTabProps) {
  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: ['/api/analytics/stats'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/analytics/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total de Contatos',
      value: stats?.totalContacts || 0,
      icon: Users,
      color: 'bg-blue-100 text-blue-600',
      change: '+12%',
    },
    {
      title: 'Mensagens Enviadas',
      value: stats?.messagesSent || 0,
      icon: Send,
      color: 'bg-green-100 text-green-600',
      change: '+25%',
    },
    {
      title: 'Taxa de Entrega',
      value: `${stats?.deliveryRate || 0}%`,
      icon: CheckCircle,
      color: 'bg-emerald-100 text-emerald-600',
      change: '+1.2%',
    },
    {
      title: 'Campanhas Ativas',
      value: stats?.activeCampaigns || 0,
      icon: Rocket,
      color: 'bg-purple-100 text-purple-600',
      change: '2 aguardando',
    },
  ];

  const quickActions = [
    {
      title: 'Criar Nova Mensagem',
      description: 'Crie templates personalizados',
      icon: Plus,
      color: 'bg-green-50 hover:bg-green-100 border-green-200',
      action: () => onTabChange('messages'),
    },
    {
      title: 'Importar Contatos',
      description: 'Upload de arquivo CSV/Excel',
      icon: Upload,
      color: 'bg-blue-50 hover:bg-blue-100 border-blue-200',
      action: () => onTabChange('contacts'),
    },
    {
      title: 'Nova Campanha',
      description: 'Lance uma campanha de marketing',
      icon: Rocket,
      color: 'bg-purple-50 hover:bg-purple-100 border-purple-200',
      action: () => onTabChange('campaigns'),
    },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color}`}>
                    <Icon className="text-xl" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600 font-medium">{stat.change}</span>
                  {stat.title !== 'Campanhas Ativas' && (
                    <span className="text-gray-600 ml-1">vs mês anterior</span>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Atividade Recente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {!stats || stats.messagesSent === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Send className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhuma atividade recente</p>
                  <p className="text-sm">Comece criando sua primeira campanha</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Send className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">Sistema inicializado</p>
                      <p className="text-xs text-gray-500">Pronto para enviar mensagens</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className={`w-full justify-between h-auto p-4 ${action.color}`}
                    onClick={action.action}
                  >
                    <div className="flex items-center space-x-3">
                      <Icon className="w-5 h-5" />
                      <div className="text-left">
                        <div className="font-medium">{action.title}</div>
                        <div className="text-sm text-gray-600">{action.description}</div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
