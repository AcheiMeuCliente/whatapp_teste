import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Plus, Rocket, Play, Pause, BarChart3, X } from 'lucide-react';
import { AuthService } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import type { Campaign, MessageTemplate } from '@/types';

const campaignSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  templateId: z.number().min(1, 'Template é obrigatório'),
  scheduledAt: z.string().optional(),
  sendingSpeed: z.enum(['fast', 'normal', 'slow']),
});

type CampaignFormData = z.infer<typeof campaignSchema>;

export function CampaignsTab() {
  const [showWizard, setShowWizard] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CampaignFormData>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      name: '',
      templateId: 0,
      sendingSpeed: 'normal',
    },
  });

  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/campaigns', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch campaigns');
      return response.json();
    },
  });

  const { data: templates = [] } = useQuery<MessageTemplate[]>({
    queryKey: ['/api/templates'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/templates', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch templates');
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CampaignFormData) => {
      const token = AuthService.getToken();
      const response = await fetch('/api/campaigns', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...data,
          scheduledAt: data.scheduledAt ? new Date(data.scheduledAt).toISOString() : null,
        }),
      });
      if (!response.ok) throw new Error('Failed to create campaign');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Campanha criada com sucesso!",
        description: "Sua campanha está pronta para ser executada.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      form.reset();
      setShowWizard(false);
    },
    onError: () => {
      toast({
        title: "Erro ao criar campanha",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CampaignFormData) => {
    createMutation.mutate(data);
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: 'bg-yellow-100 text-yellow-800',
      active: 'bg-green-100 text-green-800',
      completed: 'bg-blue-100 text-blue-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    
    const labels = {
      pending: 'Pendente',
      active: 'Ativa',
      completed: 'Concluída',
      cancelled: 'Cancelada',
    };
    
    return (
      <Badge className={variants[status as keyof typeof variants]}>
        {labels[status as keyof typeof labels]}
      </Badge>
    );
  };

  const getProgress = (campaign: Campaign) => {
    if (campaign.totalContacts === 0) return 0;
    return (campaign.messagesSent / campaign.totalContacts) * 100;
  };

  const getDeliveryRate = (campaign: Campaign) => {
    if (campaign.messagesSent === 0) return 0;
    return (campaign.messagesDelivered / campaign.messagesSent) * 100;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-xl font-semibold text-gray-900">Campanhas</h2>
        <Button onClick={() => setShowWizard(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nova Campanha
        </Button>
      </div>

      {/* Campaign Wizard */}
      {showWizard && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Nova Campanha</CardTitle>
              <p className="text-sm text-gray-600 mt-1">Configure sua campanha de mensagens</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setShowWizard(false)}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Nome da Campanha</Label>
                  <Input
                    id="name"
                    placeholder="Ex: Black Friday 2024"
                    {...form.register('name')}
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="template">Template</Label>
                  <Select onValueChange={(value) => form.setValue('templateId', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um template" />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map((template) => (
                        <SelectItem key={template.id} value={template.id.toString()}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.templateId && (
                    <p className="text-red-500 text-sm mt-1">Template é obrigatório</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="scheduledAt">Data de Envio (Opcional)</Label>
                  <Input
                    id="scheduledAt"
                    type="datetime-local"
                    {...form.register('scheduledAt')}
                  />
                </div>
                
                <div>
                  <Label htmlFor="sendingSpeed">Velocidade de Envio</Label>
                  <Select onValueChange={(value) => form.setValue('sendingSpeed', value as 'fast' | 'normal' | 'slow')}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a velocidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normal">Normal (1 msg/segundo)</SelectItem>
                      <SelectItem value="fast">Rápido (2 msg/segundo)</SelectItem>
                      <SelectItem value="slow">Lento (1 msg/2 segundos)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button type="button" variant="outline" onClick={() => setShowWizard(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'Criando...' : 'Criar Campanha'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Active Campaigns */}
      {campaignsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                <div className="h-20 bg-gray-200 rounded mb-4"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : campaigns.filter(c => c.status === 'active' || c.status === 'pending').length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Rocket className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">Nenhuma campanha ativa</p>
            <p className="text-gray-400 text-sm mt-1">
              Crie sua primeira campanha para começar a enviar mensagens
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campaigns
            .filter(campaign => campaign.status === 'active' || campaign.status === 'pending')
            .map((campaign) => {
              const progress = getProgress(campaign);
              const deliveryRate = getDeliveryRate(campaign);
              
              return (
                <Card key={campaign.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{campaign.name}</h3>
                        <p className="text-sm text-gray-600">
                          {templates.find(t => t.id === campaign.templateId)?.name || 'Template removido'}
                        </p>
                      </div>
                      {getStatusBadge(campaign.status)}
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Enviadas:</span>
                        <span className="font-medium">{campaign.messagesSent}/{campaign.totalContacts}</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Entregues:</span>
                        <span className="text-green-600 font-medium">{deliveryRate.toFixed(1)}%</span>
                      </div>
                    </div>

                    <div className="mt-4 flex space-x-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <Pause className="w-3 h-3 mr-1" />
                        Pausar
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        <BarChart3 className="w-3 h-3 mr-1" />
                        Relatório
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
        </div>
      )}

      {/* Campaign History */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Campanhas</CardTitle>
        </CardHeader>
        <CardContent>
          {campaigns.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>Nenhuma campanha encontrada</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Campanha</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Enviadas</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Taxa de Entrega</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Data</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {campaigns.map((campaign) => (
                    <tr key={campaign.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div>
                          <div className="font-medium text-gray-900">{campaign.name}</div>
                          <div className="text-sm text-gray-500">
                            {templates.find(t => t.id === campaign.templateId)?.category || 'Geral'}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(campaign.status)}
                      </td>
                      <td className="py-3 px-4 text-gray-900">{campaign.messagesSent}</td>
                      <td className="py-3 px-4 text-gray-900">
                        {getDeliveryRate(campaign).toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 text-gray-500">
                        {new Date(campaign.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button size="sm" variant="ghost" className="text-blue-600 hover:text-blue-900">
                            Ver Relatório
                          </Button>
                          <Button size="sm" variant="ghost" className="text-green-600 hover:text-green-900">
                            Duplicar
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
