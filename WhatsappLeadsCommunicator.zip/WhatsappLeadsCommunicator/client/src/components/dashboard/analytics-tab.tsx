import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Send, 
  CheckCircle, 
  Eye, 
  Reply, 
  Download, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  PieChart
} from 'lucide-react';
import { AuthService } from '@/lib/auth';
import type { UserStats, Campaign, MessageTemplate } from '@/types';

export function AnalyticsTab() {
  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ['/api/analytics/stats'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/analytics/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    },
  });

  const { data: campaigns = [] } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/campaigns', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch campaigns');
      return response.json();
    },
  });

  const { data: templates = [] } = useQuery<MessageTemplate[]>({
    queryKey: ['/api/templates'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/templates', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to templates');
      return response.json();
    },
  });

  const getDeliveryRate = (campaign: Campaign) => {
    if (campaign.messagesSent === 0) return 0;
    return (campaign.messagesDelivered / campaign.messagesSent) * 100;
  };

  const getReadRate = (campaign: Campaign) => {
    if (campaign.messagesSent === 0) return 0;
    return (campaign.messagesRead / campaign.messagesSent) * 100;
  };

  const getReplyRate = (campaign: Campaign) => {
    if (campaign.messagesSent === 0) return 0;
    return (campaign.messagesReplied / campaign.messagesSent) * 100;
  };

  const keyMetrics = [
    {
      title: 'Total Enviado',
      value: stats?.messagesSent || 0,
      icon: Send,
      color: 'bg-blue-100 text-blue-600',
      change: '+15%',
      trend: 'up',
    },
    {
      title: 'Taxa de Entrega',
      value: `${stats?.deliveryRate || 0}%`,
      icon: CheckCircle,
      color: 'bg-green-100 text-green-600',
      change: '+0.5%',
      trend: 'up',
    },
    {
      title: 'Taxa de Abertura',
      value: '89.7%',
      icon: Eye,
      color: 'bg-yellow-100 text-yellow-600',
      change: '-2%',
      trend: 'down',
    },
    {
      title: 'Taxa de Resposta',
      value: '23.4%',
      icon: Reply,
      color: 'bg-purple-100 text-purple-600',
      change: '+8%',
      trend: 'up',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-xl font-semibold text-gray-900">Relatórios e Analytics</h2>
        
        {/* Date Range Selector */}
        <div className="flex items-center space-x-3">
          <Select defaultValue="7days">
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Últimos 7 dias</SelectItem>
              <SelectItem value="30days">Últimos 30 dias</SelectItem>
              <SelectItem value="3months">Últimos 3 meses</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exportar Relatório
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {keyMetrics.map((metric, index) => {
          const Icon = metric.icon;
          const TrendIcon = metric.trend === 'up' ? TrendingUp : TrendingDown;
          const trendColor = metric.trend === 'up' ? 'text-green-600' : 'text-red-600';
          
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">{metric.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{metric.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${metric.color}`}>
                    <Icon className="text-xl" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-sm">
                    <TrendIcon className={`w-4 h-4 mr-1 ${trendColor}`} />
                    <span className={`font-medium ${trendColor}`}>{metric.change}</span>
                    <span className="text-gray-600 ml-1">vs período anterior</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Performance dos Envios
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center text-gray-500">
                <BarChart3 className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">Gráfico de Performance</p>
                <p className="text-sm">Dados de envio e entrega ao longo do tempo</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Comparison */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="w-5 h-5 mr-2" />
              Comparação de Campanhas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center text-gray-500">
                <PieChart className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">Gráfico Comparativo</p>
                <p className="text-sm">Performance entre diferentes campanhas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Relatório Detalhado</CardTitle>
        </CardHeader>
        <CardContent>
          {statsLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                </div>
              ))}
            </div>
          ) : campaigns.length === 0 ? (
            <div className="text-center py-12">
              <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">Nenhuma campanha para analisar</p>
              <p className="text-gray-400 text-sm mt-1">
                Execute campanhas para ver relatórios detalhados
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Campanha</TableHead>
                    <TableHead>Enviados</TableHead>
                    <TableHead>Entregues</TableHead>
                    <TableHead>Abertos</TableHead>
                    <TableHead>Respondidos</TableHead>
                    <TableHead>Taxa Sucesso</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {campaigns
                    .filter(campaign => campaign.messagesSent > 0)
                    .map((campaign) => {
                      const deliveryRate = getDeliveryRate(campaign);
                      const readRate = getReadRate(campaign);
                      const replyRate = getReplyRate(campaign);
                      const successRate = (deliveryRate + readRate + replyRate) / 3;
                      
                      return (
                        <TableRow key={campaign.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium text-gray-900">{campaign.name}</div>
                              <div className="text-sm text-gray-500">
                                {templates.find(t => t.id === campaign.templateId)?.category || 'Geral'}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-gray-900">{campaign.messagesSent}</TableCell>
                          <TableCell className="text-gray-900">
                            {campaign.messagesDelivered} ({deliveryRate.toFixed(1)}%)
                          </TableCell>
                          <TableCell className="text-gray-900">
                            {campaign.messagesRead} ({readRate.toFixed(1)}%)
                          </TableCell>
                          <TableCell className="text-gray-900">
                            {campaign.messagesReplied} ({replyRate.toFixed(1)}%)
                          </TableCell>
                          <TableCell>
                            <span className={`font-medium ${
                              successRate >= 70 ? 'text-green-600' : 
                              successRate >= 50 ? 'text-yellow-600' : 
                              'text-red-600'
                            }`}>
                              {successRate.toFixed(1)}%
                            </span>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
