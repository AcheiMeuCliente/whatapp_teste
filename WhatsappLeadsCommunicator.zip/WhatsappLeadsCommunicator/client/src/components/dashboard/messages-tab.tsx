import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Save, Eye, Trash2, Edit } from 'lucide-react';
import { AuthService } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import type { MessageTemplate } from '@/types';

const templateSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  content: z.string().min(1, 'Conteúdo é obrigatório').max(1000, 'Máximo 1000 caracteres'),
  category: z.string().min(1, 'Categoria é obrigatória'),
  priority: z.enum(['high', 'normal', 'low']),
});

type TemplateFormData = z.infer<typeof templateSchema>;

export function MessagesTab() {
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<TemplateFormData>({
    resolver: zodResolver(templateSchema),
    defaultValues: {
      name: '',
      content: '',
      category: 'vendas',
      priority: 'normal',
    },
  });

  const { data: templates = [], isLoading } = useQuery<MessageTemplate[]>({
    queryKey: ['/api/templates'],
    queryFn: async () => {
      const token = AuthService.getToken();
      const response = await fetch('/api/templates', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch templates');
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: TemplateFormData) => {
      const token = AuthService.getToken();
      const response = await fetch('/api/templates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create template');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Template criado com sucesso!",
        description: "Seu template está pronto para uso.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Erro ao criar template",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const token = AuthService.getToken();
      const response = await fetch(`/api/templates/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to delete template');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Template excluído com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
    },
    onError: () => {
      toast({
        title: "Erro ao excluir template",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TemplateFormData) => {
    createMutation.mutate(data);
  };

  const getPreviewMessage = () => {
    const content = form.watch('content');
    if (!content) return 'Digite uma mensagem para ver o preview...';
    
    return content
      .replace(/{nome}/g, 'João Silva')
      .replace(/{empresa}/g, 'Empresa ABC')
      .replace(/{telefone}/g, '+55 11 99999-9999');
  };

  const insertVariable = (variable: string) => {
    const currentContent = form.getValues('content');
    form.setValue('content', currentContent + variable);
  };

  const getPriorityBadge = (priority: string) => {
    const colors = {
      high: 'bg-red-100 text-red-800',
      normal: 'bg-blue-100 text-blue-800',
      low: 'bg-gray-100 text-gray-800',
    };
    
    const labels = {
      high: 'Alta',
      normal: 'Normal',
      low: 'Baixa',
    };
    
    return (
      <Badge className={colors[priority as keyof typeof colors]}>
        {labels[priority as keyof typeof labels]}
      </Badge>
    );
  };

  const getCategoryBadge = (category: string) => {
    const colors = {
      vendas: 'bg-green-100 text-green-800',
      marketing: 'bg-purple-100 text-purple-800',
      suporte: 'bg-yellow-100 text-yellow-800',
      'follow-up': 'bg-blue-100 text-blue-800',
      'boas-vindas': 'bg-pink-100 text-pink-800',
    };
    
    return (
      <Badge className={colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800'}>
        {category}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Templates de Mensagem</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Message Composer */}
        <Card>
          <CardHeader>
            <CardTitle>Criar Template</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome do Template</Label>
                <Input
                  id="name"
                  placeholder="Ex: Boas-vindas, Promoção, Follow-up"
                  {...form.register('name')}
                />
                {form.formState.errors.name && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="content">Mensagem</Label>
                <div className="relative">
                  <Textarea
                    id="content"
                    rows={8}
                    placeholder="Digite sua mensagem aqui...&#10;&#10;Use variáveis como:&#10;{nome} - Nome do contato&#10;{empresa} - Nome da empresa&#10;{telefone} - Telefone do contato"
                    {...form.register('content')}
                    className="resize-none"
                  />
                  <div className="absolute bottom-3 right-3 text-xs text-gray-500">
                    {form.watch('content')?.length || 0}/1000
                  </div>
                </div>
                {form.formState.errors.content && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.content.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Categoria</Label>
                  <Select onValueChange={(value) => form.setValue('category', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vendas">Vendas</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="suporte">Suporte</SelectItem>
                      <SelectItem value="follow-up">Follow-up</SelectItem>
                      <SelectItem value="boas-vindas">Boas-vindas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="priority">Prioridade</Label>
                  <Select onValueChange={(value) => form.setValue('priority', value as 'high' | 'normal' | 'low')}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                      <SelectItem value="low">Baixa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex space-x-3">
                <Button type="submit" disabled={createMutation.isPending} className="flex-1">
                  <Save className="w-4 h-4 mr-2" />
                  {createMutation.isPending ? 'Salvando...' : 'Salvar Template'}
                </Button>
                <Button type="button" variant="outline" onClick={() => form.reset()}>
                  Limpar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Message Preview */}
        <Card>
          <CardHeader>
            <CardTitle>Preview da Mensagem</CardTitle>
          </CardHeader>
          <CardContent>
            {/* WhatsApp-like preview */}
            <div className="bg-gray-100 rounded-lg p-4 mb-4 min-h-[200px] relative overflow-hidden">
              <div 
                className="absolute inset-0 opacity-10"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3Cpattern id='whatsapp-bg' x='0' y='0' width='100' height='100' patternUnits='userSpaceOnUse'%3E%3Ccircle cx='50' cy='50' r='2' fill='%23e5e7eb' opacity='0.4'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width='100' height='100' fill='url(%23whatsapp-bg)'/%3E%3C/svg%3E")`,
                }}
              />
              <div className="relative max-w-xs ml-auto">
                <div className="message-bubble p-3 text-sm">
                  <div className="whitespace-pre-wrap break-words">
                    {getPreviewMessage()}
                  </div>
                  <div className="text-right mt-2 text-xs text-gray-600">
                    <span>✓✓</span> <span>agora</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Template Variables Helper */}
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-900 mb-3">Variáveis Disponíveis</h4>
              <div className="grid grid-cols-1 gap-2 text-sm">
                {[
                  { var: '{nome}', desc: 'Nome do contato' },
                  { var: '{empresa}', desc: 'Nome da empresa' },
                  { var: '{telefone}', desc: 'Telefone do contato' },
                ].map((item) => (
                  <div key={item.var} className="flex items-center justify-between">
                    <div>
                      <span className="text-blue-700 font-mono">{item.var}</span>
                      <span className="text-blue-600 ml-2 text-xs">{item.desc}</span>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => insertVariable(item.var)}
                      className="text-blue-600 hover:text-blue-800 text-xs h-6 px-2"
                    >
                      Inserir
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Saved Templates */}
      <Card>
        <CardHeader>
          <CardTitle>Templates Salvos</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 rounded-lg h-32"></div>
                </div>
              ))}
            </div>
          ) : templates.length === 0 ? (
            <div className="text-center py-12">
              <Eye className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">Nenhum template criado</p>
              <p className="text-gray-400 text-sm mt-1">
                Crie seu primeiro template usando o formulário acima
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card key={template.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <h4 className="font-medium text-gray-900 truncate">{template.name}</h4>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                          onClick={() => deleteMutation.mutate(template.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-3">
                      {template.content.substring(0, 100)}
                      {template.content.length > 100 && '...'}
                    </p>
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex space-x-2">
                        {getCategoryBadge(template.category)}
                        {getPriorityBadge(template.priority)}
                      </div>
                      <span className="text-gray-500">Usado {template.usageCount}x</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
