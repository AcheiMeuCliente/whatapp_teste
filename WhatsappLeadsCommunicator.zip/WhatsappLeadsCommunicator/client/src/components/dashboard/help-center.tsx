import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  HelpCircle, 
  Search, 
  Book, 
  Video, 
  MessageCircle, 
  ExternalLink,
  ChevronRight,
  PlayCircle,
  FileText,
  Lightbulb,
  AlertCircle
} from 'lucide-react';

export function HelpCenter() {
  const [searchTerm, setSearchTerm] = useState('');

  const helpCategories = [
    {
      title: 'Primeiros Passos',
      icon: Book,
      color: 'bg-blue-100 text-blue-600',
      articles: [
        'Como criar sua primeira campanha',
        'Importando sua lista de contatos',
        'Configurando templates de mensagem',
        'Entendendo as métricas básicas',
      ]
    },
    {
      title: 'WhatsApp Business',
      icon: MessageCircle,
      color: 'bg-green-100 text-green-600',
      articles: [
        'Conectando sua conta WhatsApp Business',
        'Políticas do WhatsApp para empresas',
        'Limites de envio e boas práticas',
        'Configuração de webhook',
      ]
    },
    {
      title: 'Compliance e LGPD',
      icon: AlertCircle,
      color: 'bg-orange-100 text-orange-600',
      articles: [
        'Conformidade com LGPD',
        'Gerenciamento de consentimento',
        'Políticas anti-spam',
        'Direitos dos titulares de dados',
      ]
    },
    {
      title: 'Recursos Avançados',
      icon: Lightbulb,
      color: 'bg-purple-100 text-purple-600',
      articles: [
        'Automação de campanhas',
        'Segmentação de contatos',
        'Personalização de mensagens',
        'Análise de performance',
      ]
    },
  ];

  const videoTutorials = [
    {
      title: 'Configuração Inicial Completa',
      duration: '5:30',
      thumbnail: 'setup',
      description: 'Como configurar sua conta e enviar sua primeira mensagem'
    },
    {
      title: 'Criando Campanhas Eficazes',
      duration: '8:15',
      thumbnail: 'campaigns',
      description: 'Estratégias para campanhas de alta conversão'
    },
    {
      title: 'Análise de Resultados',
      duration: '6:45',
      thumbnail: 'analytics',
      description: 'Como interpretar métricas e melhorar performance'
    },
  ];

  const quickTips = [
    {
      title: 'Horário Ideal para Envio',
      tip: 'Envie mensagens entre 9h-12h e 14h-17h para melhor engajamento',
      type: 'time'
    },
    {
      title: 'Personalização',
      tip: 'Use o nome do contato e informações específicas para aumentar a taxa de resposta',
      type: 'personalization'
    },
    {
      title: 'Call-to-Action',
      tip: 'Inclua sempre uma ação clara: "Responda SIM", "Acesse o link", etc.',
      type: 'action'
    },
    {
      title: 'Teste A/B',
      tip: 'Teste diferentes templates com pequenos grupos antes de campanhas grandes',
      type: 'testing'
    },
  ];

  const filteredCategories = helpCategories.filter(category =>
    searchTerm === '' || 
    category.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.articles.some(article => 
      article.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">Central de Ajuda</h2>
        <Button variant="outline">
          <MessageCircle className="w-4 h-4 mr-2" />
          Falar com Suporte
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Pesquisar artigos, tutoriais..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 py-3 text-lg"
            />
          </div>
        </CardContent>
      </Card>

      {/* Quick Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lightbulb className="w-5 h-5 mr-2" />
            Dicas Rápidas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quickTips.map((tip, index) => (
              <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">{tip.title}</h4>
                <p className="text-sm text-blue-700">{tip.tip}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Video Tutorials */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Video className="w-5 h-5 mr-2" />
            Tutoriais em Vídeo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {videoTutorials.map((video, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="relative bg-gray-200 rounded-lg aspect-video mb-3 flex items-center justify-center hover:bg-gray-300 transition-colors">
                  <PlayCircle className="w-12 h-12 text-gray-600 group-hover:text-gray-700" />
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                </div>
                <h4 className="font-medium text-gray-900 group-hover:text-green-600 transition-colors">
                  {video.title}
                </h4>
                <p className="text-sm text-gray-600 mt-1">{video.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Help Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredCategories.map((category, index) => {
          const Icon = category.icon;
          
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${category.color} mr-3`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  {category.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.articles.map((article, articleIndex) => (
                    <button
                      key={articleIndex}
                      className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-lg transition-colors group"
                    >
                      <div className="flex items-center">
                        <FileText className="w-4 h-4 text-gray-400 mr-3" />
                        <span className="text-gray-700 group-hover:text-gray-900">
                          {article}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Support Options */}
      <Card>
        <CardHeader>
          <CardTitle>Precisa de Mais Ajuda?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto p-4 justify-start">
              <MessageCircle className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">Chat ao Vivo</div>
                <div className="text-sm text-gray-600">Resposta em minutos</div>
              </div>
            </Button>
            
            <Button variant="outline" className="h-auto p-4 justify-start">
              <FileText className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">Documentação</div>
                <div className="text-sm text-gray-600">Guias detalhados</div>
              </div>
            </Button>
            
            <Button variant="outline" className="h-auto p-4 justify-start">
              <ExternalLink className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">Comunidade</div>
                <div className="text-sm text-gray-600">Fórum de usuários</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}