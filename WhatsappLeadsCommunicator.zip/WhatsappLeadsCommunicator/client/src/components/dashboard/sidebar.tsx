import { BarChart3, Users, MessageSquare, Send, Gauge, Shield, HelpCircle, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
  isOpen: boolean;
}

const navigation = [
  { id: 'dashboard', name: 'Dashboard', icon: Gauge },
  { id: 'contacts', name: 'Contatos', icon: Users },
  { id: 'messages', name: 'Mensagens', icon: MessageSquare },
  { id: 'campaigns', name: 'Campanhas', icon: Send },
  { id: 'analytics', name: 'Relatórios', icon: BarChart3 },
  { id: 'compliance', name: 'Compliance', icon: Shield },
  { id: 'help', name: 'Ajuda', icon: HelpCircle },
];

export function Sidebar({ activeTab, onTabChange, onLogout, isOpen }: SidebarProps) {
  return (
    <div className={cn(
      "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 lg:translate-x-0",
      isOpen ? "translate-x-0" : "-translate-x-full"
    )}>
      <div className="flex items-center justify-center h-20 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 whatsapp-gradient rounded-lg flex items-center justify-center">
            <MessageSquare className="text-white text-lg" />
          </div>
          <span className="text-xl font-bold text-gray-900">Leads Sender</span>
        </div>
      </div>

      <nav className="mt-8 px-4">
        <div className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "w-full flex items-center px-4 py-3 text-left rounded-lg transition-colors",
                  isActive
                    ? "bg-green-50 text-green-600 border-l-4 border-green-500"
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                <Icon className="w-5 h-5 mr-3" />
                <span>{item.name}</span>
              </button>
            );
          })}
        </div>

        <div className="absolute bottom-4 left-4 right-4">
          <button
            onClick={onLogout}
            className="w-full flex items-center px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5 mr-3" />
            <span>Sair</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
