import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  FileText, 
  Users, 
  MessageSquare,
  Settings
} from 'lucide-react';

export function ComplianceTab() {
  const [complianceChecks, setComplianceChecks] = useState({
    termsAccepted: false,
    privacyCompliance: false,
    antiSpamPolicy: false,
    dataProtection: false,
    consentManagement: false,
    optOutMechanism: false,
  });

  const handleCheckChange = (key: string, checked: boolean) => {
    setComplianceChecks(prev => ({ ...prev, [key]: checked }));
  };

  const complianceItems = [
    {
      key: 'termsAccepted',
      label: 'Li e aceito os Termos de Uso do WhatsApp Business',
      description: 'Concordo em usar a plataforma apenas para comunicações legítimas e autorizadas',
      critical: true,
    },
    {
      key: 'privacyCompliance',
      label: 'Compliance com LGPD/GDPR',
      description: 'Garanto que tenho permissão legal para contatar todos os destinatários',
      critical: true,
    },
    {
      key: 'antiSpamPolicy',
      label: 'Política Anti-Spam',
      description: 'Comprometo-me a não enviar mensagens não solicitadas ou spam',
      critical: true,
    },
    {
      key: 'dataProtection',
      label: 'Proteção de Dados',
      description: 'Os dados dos contatos serão tratados de forma segura e confidencial',
      critical: false,
    },
    {
      key: 'consentManagement',
      label: 'Gerenciamento de Consentimento',
      description: 'Possuo consentimento válido de todos os contatos para comunicação',
      critical: false,
    },
    {
      key: 'optOutMechanism',
      label: 'Mecanismo de Opt-out',
      description: 'Incluirei opção de descadastro em todas as mensagens de marketing',
      critical: false,
    },
  ];

  const criticalCompliance = complianceItems
    .filter(item => item.critical)
    .every(item => complianceChecks[item.key as keyof typeof complianceChecks]);

  const allCompliance = complianceItems
    .every(item => complianceChecks[item.key as keyof typeof complianceChecks]);

  const complianceScore = Object.values(complianceChecks).filter(Boolean).length;
  const totalItems = complianceItems.length;
  const scorePercentage = Math.round((complianceScore / totalItems) * 100);

  const bestPractices = [
    {
      title: 'Horários de Envio',
      description: 'Envie mensagens apenas em horário comercial (8h-18h)',
      icon: Clock,
      status: 'recommended',
    },
    {
      title: 'Personalização',
      description: 'Use o nome do destinatário sempre que possível',
      icon: Users,
      status: 'recommended',
    },
    {
      title: 'Frequência',
      description: 'Evite múltiplas mensagens no mesmo dia',
      icon: MessageSquare,
      status: 'warning',
    },
    {
      title: 'Conteúdo Relevante',
      description: 'Envie apenas conteúdo útil e relacionado ao interesse do contato',
      icon: FileText,
      status: 'critical',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'recommended': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'critical': return AlertTriangle;
      case 'warning': return AlertTriangle;
      case 'recommended': return CheckCircle;
      default: return CheckCircle;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">Compliance e Boas Práticas</h2>
        <Badge className={criticalCompliance ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
          {criticalCompliance ? 'Compliance OK' : 'Ação Necessária'}
        </Badge>
      </div>

      {/* Compliance Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Score de Compliance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-3xl font-bold text-gray-900">{scorePercentage}%</div>
              <div className="text-sm text-gray-600">{complianceScore} de {totalItems} itens completados</div>
            </div>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
              scorePercentage >= 80 ? 'bg-green-100' : 
              scorePercentage >= 60 ? 'bg-yellow-100' : 'bg-red-100'
            }`}>
              <Shield className={`w-8 h-8 ${
                scorePercentage >= 80 ? 'text-green-600' : 
                scorePercentage >= 60 ? 'text-yellow-600' : 'text-red-600'
              }`} />
            </div>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-300 ${
                scorePercentage >= 80 ? 'bg-green-500' : 
                scorePercentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${scorePercentage}%` }}
            ></div>
          </div>
        </CardContent>
      </Card>

      {/* Critical Alert */}
      {!criticalCompliance && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Atenção:</strong> Itens críticos de compliance não foram aceitos. 
            É necessário completar todos os itens obrigatórios antes de enviar campanhas.
          </AlertDescription>
        </Alert>
      )}

      {/* Compliance Checklist */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Verificação de Compliance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {complianceItems.map((item) => (
            <div 
              key={item.key} 
              className={`border rounded-lg p-4 transition-colors ${
                item.critical ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-start space-x-3">
                <Checkbox
                  id={item.key}
                  checked={complianceChecks[item.key as keyof typeof complianceChecks]}
                  onCheckedChange={(checked) => 
                    handleCheckChange(item.key, checked as boolean)
                  }
                  className="mt-1"
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <label 
                      htmlFor={item.key} 
                      className="font-medium text-gray-900 cursor-pointer"
                    >
                      {item.label}
                    </label>
                    {item.critical && (
                      <Badge className="bg-red-100 text-red-800 text-xs">
                        Obrigatório
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Best Practices */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Boas Práticas para WhatsApp Marketing
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bestPractices.map((practice, index) => {
              const Icon = practice.icon;
              const StatusIcon = getStatusIcon(practice.status);
              
              return (
                <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-gray-900">{practice.title}</h4>
                        <Badge className={getStatusColor(practice.status)}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {practice.status === 'critical' ? 'Crítico' : 
                           practice.status === 'warning' ? 'Atenção' : 'Recomendado'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{practice.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-3">
        <Button variant="outline">
          <FileText className="w-4 h-4 mr-2" />
          Baixar Política de Uso
        </Button>
        <Button 
          disabled={!allCompliance}
          className={allCompliance ? 'whatsapp-gradient' : ''}
        >
          <CheckCircle className="w-4 h-4 mr-2" />
          {allCompliance ? 'Compliance Verificado' : 'Complete Todos os Itens'}
        </Button>
      </div>
    </div>
  );
}